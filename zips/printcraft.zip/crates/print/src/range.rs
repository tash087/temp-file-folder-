//! Pages to Print: all, a range ("1-3, 6, 9-", page labels allowed), odd or even pages, reverse.

use crate::PrintError;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Subset {
    #[default]
    All,
    Odd,
    Even,
}

/// Resolve one range token: a page label, or a number (1-based).
fn page_of(tok: &str, count: usize, labels: &[String]) -> Result<usize, PrintError> {
    let t = tok.trim();
    // Page labels win over numbers (Acrobat's "use logical page numbers").
    if let Some(i) = labels.iter().position(|l| l == t) {
        return Ok(i);
    }
    match t.parse::<usize>() {
        Ok(n) if n >= 1 && n <= count => Ok(n - 1),
        Ok(n) => Err(PrintError::Invalid(format!("page {n} is out of range (1–{count})"))),
        Err(_) => Err(PrintError::Invalid(format!("{t:?} is not a page number or label"))),
    }
}

/// The pages to print (0-based, in print order). `range` is `None` for all pages; it may list
/// numbers and labels with `-` ranges (open-ended allowed: `5-`, `-3`). The subset counts the
/// selected pages (the first selected is "odd"), as Acrobat does.
pub fn select_pages(count: usize, range: Option<&str>, labels: &[String], subset: Subset, reverse: bool) -> Result<Vec<usize>, PrintError> {
    let mut pages = Vec::new();
    match range.map(str::trim).filter(|r| !r.is_empty()) {
        None => pages.extend(0..count),
        Some(r) => {
            for part in r.split([',', ';']).map(str::trim).filter(|p| !p.is_empty()) {
                match part.split_once('-') {
                    // A label may itself contain a dash ("A-1"): try the whole token first.
                    Some(_) if labels.iter().any(|l| l == part) => pages.push(page_of(part, count, labels)?),
                    Some((a, b)) => {
                        let from = if a.trim().is_empty() { 0 } else { page_of(a, count, labels)? };
                        let to = if b.trim().is_empty() { count.saturating_sub(1) } else { page_of(b, count, labels)? };
                        if from <= to {
                            pages.extend(from..=to);
                        } else {
                            pages.extend((to..=from).rev());
                        }
                    }
                    None => pages.push(page_of(part, count, labels)?),
                }
            }
        }
    }
    let mut out: Vec<usize> = match subset {
        Subset::All => pages,
        Subset::Odd => pages.into_iter().step_by(2).collect(),
        Subset::Even => pages.into_iter().skip(1).step_by(2).collect(),
    };
    if reverse {
        out.reverse();
    }
    if out.is_empty() {
        return Err(PrintError::NoPages);
    }
    Ok(out)
}
