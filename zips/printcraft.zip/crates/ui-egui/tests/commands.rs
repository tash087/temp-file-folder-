//! The command registry drives menus, shortcuts and the palette: every registered command must
//! be implemented, disabled commands must say why, and every surface must reach the same action.

use egui::{Key, Modifiers};
use egui_kittest::Harness;
use egui_kittest::kittest::Queryable;
use printcraft_engine::commands::COMMANDS;
use printcraft_ui_egui::{Dialog, PrintCraftApp};

fn fixture(n: usize) -> Vec<u8> {
    let mut objs: Vec<String> = vec!["<< /Type /Catalog /Pages 2 0 R >>".into()];
    let kids: Vec<String> = (0..n).map(|i| format!("{} 0 R", 4 + 2 * i)).collect();
    objs.push(format!("<< /Type /Pages /Kids [{}] /Count {n} /MediaBox [0 0 200 300] >>", kids.join(" ")));
    objs.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>".into());
    for i in 0..n {
        objs.push(format!("<< /Type /Page /Parent 2 0 R /Contents {} 0 R /Resources << /Font << /F1 3 0 R >> >> >>", 5 + 2 * i));
        let body = format!("BT /F1 24 Tf 20 150 Td (Page {}) Tj ET", i + 1);
        objs.push(format!("<< /Length {} >>\nstream\n{body}\nendstream", body.len()));
    }
    let mut out = b"%PDF-1.7\n".to_vec();
    let mut offsets = Vec::new();
    for (i, o) in objs.iter().enumerate() {
        offsets.push(out.len());
        out.extend_from_slice(format!("{} 0 obj\n{o}\nendobj\n", i + 1).as_bytes());
    }
    let xref = out.len();
    out.extend_from_slice(format!("xref\n0 {}\n0000000000 65535 f \n", objs.len() + 1).as_bytes());
    for o in offsets {
        out.extend_from_slice(format!("{o:010} 00000 n \n").as_bytes());
    }
    out.extend_from_slice(format!("trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n", objs.len() + 1).as_bytes());
    out
}

fn harness() -> Harness<'static, PrintCraftApp> {
    let mut h = Harness::builder().with_size(egui::vec2(1400.0, 900.0)).build_eframe(|_cc| {
        let mut app = PrintCraftApp::new();
        app.open_bytes("doc.pdf", None, fixture(3)).unwrap();
        app
    });
    h.run_steps(4);
    h
}

/// Commands that open a native file picker can't run headless.
/// (Create ▸ Clipboard reads the system clipboard: tests use `create_from_clip`.)
const PICKERS: &[&str] = &[
    "file.open",
    "page.combine",
    "page.insert",
    "file.save_as",
    "create.file",
    "create.images",
    "page.replace",
    "create.clipboard",
    "a11y.report",
    "ocr.recognize_batch",
    "form.merge_data",
    "export.docx",
    "export.html",
    "export.rtf",
];

#[test]
fn every_registered_command_is_implemented() {
    for spec in COMMANDS {
        if PICKERS.contains(&spec.id) {
            continue;
        }
        let mut app = PrintCraftApp::new();
        if spec.id.starts_with("form.") || spec.id == "comment.flatten" {
            app.open_bytes("form.pdf", None, include_bytes!("data/form.pdf").to_vec()).unwrap();
        } else {
            app.open_bytes("doc.pdf", None, fixture(3)).unwrap();
        }
        // Give undo/redo something to do.
        app.apply_edit(printcraft_engine::Edit::RotatePages { pages: vec![0], degrees: 90 });
        if spec.id == "edit.redo" {
            app.undo();
        }
        if spec.id.starts_with("edit.") && (spec.id.ends_with(".update") || spec.id.ends_with(".remove")) {
            use printcraft_engine::{Background, Edit, HeaderFooter, Watermark};
            let mut hf = HeaderFooter::default();
            hf.text[1] = "x".into();
            app.apply_edit(Edit::AddHeaderFooter { pages: vec![0], settings: hf, replace: false });
            app.apply_edit(Edit::AddWatermark {
                pages: vec![0],
                settings: Watermark { text: "x".into(), ..Watermark::default() },
                replace: false,
                file: None,
            });
            app.apply_edit(Edit::AddBackground {
                pages: vec![0],
                settings: Background { color: [1.0; 3], opacity: 1.0, ..Background::default() },
                replace: false,
                file: None,
            });
        }
        if matches!(spec.id, "comment.flatten" | "comment.export" | "comment.summarize") {
            use printcraft_engine::{Edit, NewAnnotation, Shape, Style};
            let shape = Shape::Rectangle { rect: [10.0, 10.0, 50.0, 50.0] };
            app.apply_edit(Edit::AddAnnotation(NewAnnotation {
                page: 0,
                style: Style::default_for(&shape),
                shape,
                contents: String::new(),
                author: String::new(),
            }));
        }
        if spec.id.starts_with("redact.") {
            use printcraft_engine::{Edit, NewAnnotation, Shape, Style};
            let shape = Shape::Redact {
                quads: vec![printcraft_engine::rect_quad([10.0, 10.0, 50.0, 50.0])],
                overlay: String::new(),
                look: Default::default(),
            };
            app.apply_edit(Edit::AddAnnotation(NewAnnotation {
                page: 0,
                style: Style::default_for(&shape),
                shape,
                contents: String::new(),
                author: String::new(),
            }));
        }
        if spec.id == "protect.remove" {
            let p = printcraft_engine::Protection { open_password: Some("pw".into()), ..Default::default() };
            app.apply_edit(printcraft_engine::Edit::Protect(p));
        }
        let dir = std::env::temp_dir().join(format!("printcraft-cmd-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        app.save_override = Some(dir.join("out.pdf").to_string_lossy().into_owned());
        assert!(app.execute(spec.id), "{} is registered but not implemented (or wrongly disabled)", spec.id);
    }
}

#[test]
fn disabled_commands_explain_themselves() {
    let mut app = PrintCraftApp::new();
    assert!(!app.execute("file.save"));
    assert_eq!(app.toast.as_ref().map(|t| t.0.as_str()), Some("Open a document first"));
    app.open_bytes("doc.pdf", None, fixture(2)).unwrap();
    assert!(!app.execute("edit.undo"));
    assert_eq!(app.toast.as_ref().map(|t| t.0.as_str()), Some("Nothing to undo"));
    assert!(!app.execute("no.such.command"));
}

#[test]
fn shortcuts_run_registered_commands() {
    let mut h = harness();
    h.key_press_modifiers(Modifiers::COMMAND, Key::D);
    h.run_steps(2);
    assert!(matches!(h.state().dialog, Some(Dialog::Properties(_))));
    h.state_mut().dialog = None;
    h.key_press_modifiers(Modifiers::COMMAND, Key::K);
    h.run_steps(2);
    assert!(h.state().palette_open);
    h.key_press(Key::Escape);
    h.run_steps(2);
    h.key_press_modifiers(Modifiers::COMMAND | Modifiers::CTRL, Key::H);
    h.run_steps(2);
    assert_eq!(h.state().mode, printcraft_ui_egui::Mode::Read);
}

#[test]
fn the_palette_lists_commands_with_shortcuts_and_runs_them() {
    let mut h = harness();
    h.state_mut().set_option("palette", "rotate pages clockwise").unwrap();
    h.run_steps(3);
    h.get_by_label("Rotate pages clockwise");
    h.key_press(Key::Enter);
    h.run_steps(3);
    let app = h.state();
    assert!(!app.palette_open, "Enter runs the top hit and closes the palette");
    let doc = app.session.get(app.views[0].id).unwrap();
    assert_eq!(doc.info.pages[0].rotation, 90);
    assert_eq!(doc.can_undo(), Some("Rotate page"));
}

#[test]
fn the_pages_menu_comes_from_the_registry() {
    let mut h = harness();
    h.get_by_label("Menu").click();
    h.run_steps(2);
    h.get_by_label("Pages ⏵").hover();
    h.run_steps(3);
    h.get_by_label_contains("Delete pages").click();
    h.run_steps(3);
    let app = h.state();
    assert_eq!(app.session.get(app.views[0].id).unwrap().info.pages.len(), 2);
}

#[test]
fn the_shortcuts_dialog_lists_the_real_bindings() {
    let mut h = harness();
    h.state_mut().execute("help.shortcuts");
    h.run_steps(3);
    let mac = cfg!(target_os = "macos");
    h.get_by_label(if mac { "⇧⌘S" } else { "Ctrl+Shift+S" });
    h.get_by_label("Save as");
}

#[test]
fn full_screen_toggles_by_shortcut_and_command_and_escape_leaves() {
    let mut h = harness();
    h.key_press_modifiers(Modifiers::COMMAND, Key::L);
    h.run_steps(2);
    assert!(h.state().full_screen, "⌘L / Ctrl+L enters full screen");
    h.key_press(Key::Escape);
    h.run_steps(2);
    assert!(!h.state().full_screen, "Escape leaves full screen");
    h.state_mut().execute("view.full_screen");
    h.run_steps(2);
    assert!(h.state().full_screen);
    h.state_mut().execute("view.full_screen");
    h.run_steps(2);
    assert!(!h.state().full_screen, "the command toggles back");
}

#[test]
fn the_about_dialog_shows_the_running_version() {
    let mut h = harness();
    h.state_mut().execute("help.about");
    h.run_steps(3);
    h.get_by_label_contains(&format!("Version {}", env!("CARGO_PKG_VERSION")));
}
