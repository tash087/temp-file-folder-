//! PKCS #12 digital ID files (RFC 7292): `.p12` / `.pfx`, as Acrobat, OpenSSL, macOS Keychain
//! and Windows export them.
//!
//! Reading supports PBES2 (PBKDF2 with HMAC-SHA-1/256/384/512; AES-128/192/256-CBC or
//! 3DES-CBC) and the legacy PKCS #12 PBE schemes (SHA-1 with 3DES or RC2), and checks the MAC.
//! Writing uses PBES2 AES-256-CBC with PBKDF2-HMAC-SHA-256 and an HMAC-SHA-256 MAC, OpenSSL 3's
//! defaults.

use cbc::cipher::block_padding::Pkcs7;
use cbc::cipher::{BlockModeDecrypt, BlockModeEncrypt, InnerIvInit, KeyIvInit};
use hmac::Mac;

use crate::SignError;
use crate::der::{self, Tlv, tag};
use crate::keys::{DigestAlg, PrivateKey};
use crate::x509::Certificate;

const DATA: &str = "1.2.840.113549.1.7.1";
const ENCRYPTED_DATA: &str = "1.2.840.113549.1.7.6";
const KEY_BAG: &str = "1.2.840.113549.1.12.10.1.1";
const SHROUDED_KEY_BAG: &str = "1.2.840.113549.1.12.10.1.2";
const CERT_BAG: &str = "1.2.840.113549.1.12.10.1.3";
const X509_CERT: &str = "1.2.840.113549.1.9.22.1";
const FRIENDLY_NAME: &str = "1.2.840.113549.1.9.20";
const LOCAL_KEY_ID: &str = "1.2.840.113549.1.9.21";
const PBES2: &str = "1.2.840.113549.1.5.13";
const PBKDF2: &str = "1.2.840.113549.1.5.12";
const HMAC_SHA1: &str = "1.2.840.113549.2.7";
const HMAC_SHA256: &str = "1.2.840.113549.2.9";
const HMAC_SHA384: &str = "1.2.840.113549.2.10";
const HMAC_SHA512: &str = "1.2.840.113549.2.11";
const AES128_CBC: &str = "2.16.840.1.101.3.4.1.2";
const AES192_CBC: &str = "2.16.840.1.101.3.4.1.22";
const AES256_CBC: &str = "2.16.840.1.101.3.4.1.42";
const DES_EDE3_CBC: &str = "1.2.840.113549.3.7";
const PBE_SHA_3DES: &str = "1.2.840.113549.1.12.1.3";
const PBE_SHA_2DES: &str = "1.2.840.113549.1.12.1.4";
const PBE_SHA_RC2_128: &str = "1.2.840.113549.1.12.1.5";
const PBE_SHA_RC2_40: &str = "1.2.840.113549.1.12.1.6";

/// What a digital ID file holds: the signing key, its certificate and any others (issuers).
#[derive(Debug)]
pub struct DigitalId {
    pub key: PrivateKey,
    pub certificate: Certificate,
    /// The other certificates in the file (the chain), without the signer's.
    pub chain: Vec<Certificate>,
    pub friendly_name: Option<String>,
}

fn bad(what: &str) -> SignError {
    SignError::Malformed(format!("PKCS #12: {what}"))
}

/// The password as a BMPString with its terminating NUL (RFC 7292 Appendix B.1).
fn bmp(password: &str) -> Vec<u8> {
    let mut v: Vec<u8> = password.encode_utf16().flat_map(u16::to_be_bytes).collect();
    v.extend([0, 0]);
    v
}

/// The PKCS #12 key derivation function (RFC 7292 Appendix B.2).
fn pkcs12_kdf(alg: DigestAlg, password: &[u8], salt: &[u8], id: u8, iterations: u32, n: usize) -> Vec<u8> {
    let (u, v) = match alg {
        DigestAlg::Sha1 => (20, 64),
        DigestAlg::Sha256 => (32, 64),
        DigestAlg::Sha384 => (48, 128),
        DigestAlg::Sha512 => (64, 128),
    };
    let _ = u;
    let fill = |s: &[u8]| -> Vec<u8> {
        if s.is_empty() {
            return Vec::new();
        }
        let len = v * s.len().div_ceil(v);
        s.iter().cycle().take(len).copied().collect()
    };
    let d = vec![id; v];
    let mut i: Vec<u8> = [fill(salt), fill(password)].concat();
    let mut out = Vec::with_capacity(n);
    while out.len() < n {
        let mut a = alg.digest(&[&d, &i]);
        for _ in 1..iterations.max(1) {
            a = alg.digest(&[&a]);
        }
        let b: Vec<u8> = a.iter().cycle().take(v).copied().collect();
        for chunk in i.chunks_mut(v) {
            // chunk = (chunk + b + 1) mod 2^(8v)
            let mut carry = 1u16;
            for k in (0..v).rev() {
                let s = chunk[k] as u16 + b[k] as u16 + carry;
                chunk[k] = s as u8;
                carry = s >> 8;
            }
        }
        out.extend_from_slice(&a);
    }
    out.truncate(n);
    out
}

#[derive(Clone, Copy)]
enum Cipher {
    Aes128,
    Aes192,
    Aes256,
    TripleDes,
    Rc2(usize),
}

impl Cipher {
    fn key_len(self) -> usize {
        match self {
            Cipher::Aes128 => 16,
            Cipher::Aes192 => 24,
            Cipher::Aes256 => 32,
            Cipher::TripleDes => 24,
            Cipher::Rc2(bits) => bits / 8,
        }
    }

    fn decrypt(self, key: &[u8], iv: &[u8], ct: &[u8]) -> Result<Vec<u8>, SignError> {
        let wrong = || SignError::WrongPassword;
        let r = match self {
            Cipher::Aes128 => cbc::Decryptor::<aes::Aes128>::new_from_slices(key, iv).map_err(|_| wrong())?.decrypt_padded_vec::<Pkcs7>(ct),
            Cipher::Aes192 => cbc::Decryptor::<aes::Aes192>::new_from_slices(key, iv).map_err(|_| wrong())?.decrypt_padded_vec::<Pkcs7>(ct),
            Cipher::Aes256 => cbc::Decryptor::<aes::Aes256>::new_from_slices(key, iv).map_err(|_| wrong())?.decrypt_padded_vec::<Pkcs7>(ct),
            Cipher::TripleDes => cbc::Decryptor::<des::TdesEde3>::new_from_slices(key, iv).map_err(|_| wrong())?.decrypt_padded_vec::<Pkcs7>(ct),
            Cipher::Rc2(bits) => {
                let c = rc2::Rc2::new_with_eff_key_len(key, bits);
                cbc::Decryptor::<rc2::Rc2>::inner_iv_slice_init(c, iv).map_err(|_| wrong())?.decrypt_padded_vec::<Pkcs7>(ct)
            }
        };
        r.map_err(|_| wrong())
    }
}

fn hmac(alg: DigestAlg, key: &[u8], data: &[u8]) -> Result<Vec<u8>, SignError> {
    fn run<D: hmac::EagerHash>(key: &[u8], data: &[u8]) -> Result<Vec<u8>, SignError>
    where
        hmac::Hmac<D>: hmac::KeyInit + Mac,
    {
        // HMAC takes any key length, so this never fails in practice.
        let mut m = <hmac::Hmac<D> as hmac::KeyInit>::new_from_slice(key).map_err(|_| bad("MAC key"))?;
        m.update(data);
        Ok(m.finalize().into_bytes().to_vec())
    }
    match alg {
        DigestAlg::Sha1 => run::<sha1::Sha1>(key, data),
        DigestAlg::Sha256 => run::<sha2::Sha256>(key, data),
        DigestAlg::Sha384 => run::<sha2::Sha384>(key, data),
        DigestAlg::Sha512 => run::<sha2::Sha512>(key, data),
    }
}

fn pbkdf2(prf: DigestAlg, password: &[u8], salt: &[u8], rounds: u32, len: usize) -> Vec<u8> {
    let mut out = vec![0u8; len];
    match prf {
        DigestAlg::Sha1 => pbkdf2::pbkdf2_hmac::<sha1::Sha1>(password, salt, rounds, &mut out),
        DigestAlg::Sha256 => pbkdf2::pbkdf2_hmac::<sha2::Sha256>(password, salt, rounds, &mut out),
        DigestAlg::Sha384 => pbkdf2::pbkdf2_hmac::<sha2::Sha384>(password, salt, rounds, &mut out),
        DigestAlg::Sha512 => pbkdf2::pbkdf2_hmac::<sha2::Sha512>(password, salt, rounds, &mut out),
    }
    out
}

/// Decrypt `ct` with the password-based scheme `alg` (an AlgorithmIdentifier).
fn pbe_decrypt(alg: &Tlv<'_>, password: &str, ct: &[u8]) -> Result<Vec<u8>, SignError> {
    let parts = alg.children()?;
    let o = parts.first().ok_or_else(|| bad("algorithm"))?.oid()?;
    let params = parts.get(1).ok_or_else(|| bad("algorithm parameters"))?;
    match o.as_str() {
        PBES2 => {
            let p = params.children()?;
            let [kdf, scheme] = p.as_slice() else { return Err(bad("PBES2 parameters")) };
            let kdf = kdf.children()?;
            if kdf.first().map(|o| o.oid()).transpose()?.as_deref() != Some(PBKDF2) {
                return Err(SignError::Unsupported("PBES2 key derivation other than PBKDF2".into()));
            }
            let kp = kdf.get(1).ok_or_else(|| bad("PBKDF2 parameters"))?.children()?;
            let salt = kp.first().ok_or_else(|| bad("salt"))?.expect(tag::OCTET_STRING, "salt")?.value;
            let rounds = kp.get(1).ok_or_else(|| bad("iterations"))?.u64()? as u32;
            let prf = match kp
                .iter()
                .skip(2)
                .find(|t| t.tag == tag::SEQUENCE)
                .and_then(|a| a.children().ok())
                .and_then(|a| a.first().and_then(|o| o.oid().ok()))
            {
                None => DigestAlg::Sha1,
                Some(o) => match o.as_str() {
                    HMAC_SHA1 => DigestAlg::Sha1,
                    HMAC_SHA256 => DigestAlg::Sha256,
                    HMAC_SHA384 => DigestAlg::Sha384,
                    HMAC_SHA512 => DigestAlg::Sha512,
                    other => return Err(SignError::Unsupported(format!("PBKDF2 PRF {other}"))),
                },
            };
            let sc = scheme.children()?;
            let cipher = match sc.first().map(|o| o.oid()).transpose()?.as_deref() {
                Some(AES128_CBC) => Cipher::Aes128,
                Some(AES192_CBC) => Cipher::Aes192,
                Some(AES256_CBC) => Cipher::Aes256,
                Some(DES_EDE3_CBC) => Cipher::TripleDes,
                other => return Err(SignError::Unsupported(format!("PBES2 cipher {}", other.unwrap_or("?")))),
            };
            let iv = sc.get(1).ok_or_else(|| bad("IV"))?.expect(tag::OCTET_STRING, "IV")?.value;
            let key = pbkdf2(prf, password.as_bytes(), salt, rounds, cipher.key_len());
            cipher.decrypt(&key, iv, ct)
        }
        PBE_SHA_3DES | PBE_SHA_2DES | PBE_SHA_RC2_128 | PBE_SHA_RC2_40 => {
            let p = params.children()?;
            let salt = p.first().ok_or_else(|| bad("salt"))?.expect(tag::OCTET_STRING, "salt")?.value;
            let rounds = p.get(1).ok_or_else(|| bad("iterations"))?.u64()? as u32;
            let (cipher, key_len, iv_len) = match o.as_str() {
                PBE_SHA_3DES => (Cipher::TripleDes, 24, 8),
                PBE_SHA_2DES => (Cipher::TripleDes, 16, 8),
                PBE_SHA_RC2_128 => (Cipher::Rc2(128), 16, 8),
                _ => (Cipher::Rc2(40), 5, 8),
            };
            let pw = bmp(password);
            let mut key = pkcs12_kdf(DigestAlg::Sha1, &pw, salt, 1, rounds, key_len);
            if key.len() == 16 && matches!(cipher, Cipher::TripleDes) {
                // Two-key 3DES: K1 K2 K1.
                let k1 = key[..8].to_vec();
                key.extend(k1);
            }
            let iv = pkcs12_kdf(DigestAlg::Sha1, &pw, salt, 2, rounds, iv_len);
            cipher.decrypt(&key, &iv, ct)
        }
        other => Err(SignError::Unsupported(format!("PKCS #12 encryption {other}"))),
    }
}

struct Bag {
    kind: BagKind,
    local_key_id: Option<Vec<u8>>,
    friendly_name: Option<String>,
}

enum BagKind {
    Key(Vec<u8>),
    Cert(Vec<u8>),
}

fn bags(safe_contents: &[u8], password: &str, out: &mut Vec<Bag>) -> Result<(), SignError> {
    for bag in Tlv::parse_all(safe_contents)?.children()? {
        let f = bag.children()?;
        let Some(id) = f.first().and_then(|o| o.oid().ok()) else { continue };
        let Some(value) = f.get(1).filter(|v| v.tag == tag::ctx(0)).and_then(|v| v.inner().ok()) else { continue };
        let (mut local_key_id, mut friendly_name) = (None, None);
        if let Some(attrs) = f.get(2) {
            for a in attrs.children()? {
                let p = a.children()?;
                let v = p.get(1).and_then(|s| s.children().ok()).and_then(|s| s.into_iter().next());
                match (p.first().and_then(|o| o.oid().ok()).as_deref(), v) {
                    (Some(LOCAL_KEY_ID), Some(v)) => local_key_id = Some(v.value.to_vec()),
                    (Some(FRIENDLY_NAME), Some(v)) => friendly_name = v.text(),
                    _ => {}
                }
            }
        }
        let kind = match id.as_str() {
            KEY_BAG => BagKind::Key(value.raw.to_vec()),
            SHROUDED_KEY_BAG => {
                let p = value.children()?;
                let [alg, data] = p.as_slice() else { return Err(bad("EncryptedPrivateKeyInfo")) };
                BagKind::Key(pbe_decrypt(alg, password, data.value)?)
            }
            CERT_BAG => {
                let p = value.children()?;
                if p.first().and_then(|o| o.oid().ok()).as_deref() != Some(X509_CERT) {
                    continue;
                }
                let Some(c) = p.get(1).and_then(|c| c.inner().ok()) else { continue };
                BagKind::Cert(c.value.to_vec())
            }
            _ => continue,
        };
        out.push(Bag { kind, local_key_id, friendly_name });
    }
    Ok(())
}

/// Open a `.p12` / `.pfx` file. A wrong password is [`SignError::WrongPassword`].
pub fn open(bytes: &[u8], password: &str) -> Result<DigitalId, SignError> {
    let pfx = Tlv::parse_all(bytes).map_err(|_| bad("not a PKCS #12 file"))?.children()?;
    let auth_safe = pfx.get(1).ok_or_else(|| bad("authSafe"))?.children()?;
    if auth_safe.first().map(|o| o.oid()).transpose()?.as_deref() != Some(DATA) {
        return Err(SignError::Unsupported("public-key protected PKCS #12 files".into()));
    }
    let content = auth_safe.get(1).ok_or_else(|| bad("authSafe content"))?.inner()?.expect(tag::OCTET_STRING, "authSafe")?.value;
    // The MAC proves the password before anything is decrypted.
    if let Some(mac) = pfx.get(2) {
        let m = mac.children()?;
        let digest_info = m.first().ok_or_else(|| bad("MacData"))?.children()?;
        let alg = digest_info.first().ok_or_else(|| bad("MAC algorithm"))?.children()?;
        let alg_oid = alg.first().ok_or_else(|| bad("MAC algorithm"))?.oid()?;
        let alg = DigestAlg::from_oid(&alg_oid).ok_or_else(|| SignError::Unsupported(format!("MAC digest {alg_oid}")))?;
        let expected = digest_info.get(1).ok_or_else(|| bad("MAC"))?.value;
        let salt = m.get(1).ok_or_else(|| bad("MAC salt"))?.value;
        let iterations = m.get(2).map(|i| i.u64()).transpose()?.unwrap_or(1) as u32;
        let key_len = alg.digest(&[]).len();
        let key = pkcs12_kdf(alg, &bmp(password), salt, 3, iterations, key_len);
        if hmac(alg, &key, content)? != expected {
            return Err(SignError::WrongPassword);
        }
    }
    let mut all = Vec::new();
    for ci in Tlv::parse_all(content)?.children()? {
        let p = ci.children()?;
        let kind = p.first().ok_or_else(|| bad("ContentInfo"))?.oid()?;
        let body = p.get(1).ok_or_else(|| bad("ContentInfo content"))?.inner()?;
        match kind.as_str() {
            DATA => bags(body.expect(tag::OCTET_STRING, "SafeContents")?.value, password, &mut all)?,
            ENCRYPTED_DATA => {
                let ed = body.children()?;
                let eci = ed.get(1).ok_or_else(|| bad("EncryptedContentInfo"))?.children()?;
                let alg = eci.get(1).ok_or_else(|| bad("content encryption algorithm"))?;
                let ct = match eci.get(2) {
                    Some(t) if t.tag == tag::ctx_prim(0) => t.value.to_vec(),
                    // Constructed form: a sequence of OCTET STRING segments.
                    Some(t) if t.tag == tag::ctx(0) => t.children()?.iter().flat_map(|s| s.value.iter().copied()).collect(),
                    _ => return Err(bad("encryptedContent")),
                };
                let plain = pbe_decrypt(alg, password, &ct)?;
                bags(&plain, password, &mut all)?;
            }
            _ => {}
        }
    }
    let (key_bag, pkcs8) = all
        .iter()
        .find_map(|b| match &b.kind {
            BagKind::Key(k) => Some((b, k)),
            _ => None,
        })
        .ok_or_else(|| bad("no private key"))?;
    let key = PrivateKey::from_pkcs8(pkcs8)?;
    let certs: Vec<(Certificate, &Bag)> = all
        .iter()
        .filter_map(|b| match &b.kind {
            BagKind::Cert(c) => Certificate::parse(c).ok().map(|c| (c, b)),
            _ => None,
        })
        .collect();
    // The signer's certificate: the same local key id, else the one with the key's public key.
    let idx = certs
        .iter()
        .position(|(_, b)| key_bag.local_key_id.is_some() && b.local_key_id == key_bag.local_key_id)
        .or_else(|| certs.iter().position(|(c, _)| &c.public_key == key.public_key()))
        .ok_or_else(|| bad("no certificate for the private key"))?;
    let friendly_name = key_bag.friendly_name.clone().or_else(|| certs[idx].1.friendly_name.clone());
    let mut certs: Vec<Certificate> = certs.into_iter().map(|(c, _)| c).collect();
    let certificate = certs.remove(idx);
    if &certificate.public_key != key.public_key() {
        return Err(bad("the certificate does not match the private key"));
    }
    Ok(DigitalId { key, certificate, chain: certs, friendly_name })
}

fn random(n: usize) -> Result<Vec<u8>, SignError> {
    let mut v = vec![0u8; n];
    getrandom::fill(&mut v).map_err(|e| SignError::Crypto(format!("no randomness: {e}")))?;
    Ok(v)
}

/// Write a digital ID as a `.p12` protected by `password`.
pub fn write(id: &DigitalId, password: &str) -> Result<Vec<u8>, SignError> {
    const ITER: u32 = 2048;
    let encrypt = |plain: &[u8]| -> Result<Vec<u8>, SignError> {
        let (salt, iv) = (random(16)?, random(16)?);
        let key = pbkdf2(DigestAlg::Sha256, password.as_bytes(), &salt, ITER, 32);
        let ct = cbc::Encryptor::<aes::Aes256>::new_from_slices(&key, &iv)
            .map_err(|_| SignError::Crypto("AES".into()))?
            .encrypt_padded_vec::<Pkcs7>(plain);
        let kdf = der::seq(&[
            &der::oid(PBKDF2),
            &der::seq(&[&der::octets(&salt), &der::int(ITER as u64), &der::seq(&[&der::oid(HMAC_SHA256), &der::null()])]),
        ]);
        let alg = der::seq(&[&der::oid(PBES2), &der::seq(&[&kdf, &der::seq(&[&der::oid(AES256_CBC), &der::octets(&iv)])])]);
        Ok(der::seq(&[&alg, &der::octets(&ct)]))
    };
    let local_id = DigestAlg::Sha1.digest(&[&id.certificate.raw]);
    let mut attrs: Vec<Vec<u8>> = vec![der::seq(&[&der::oid(LOCAL_KEY_ID), &der::set_of(&[&der::octets(&local_id)])])];
    if let Some(n) = &id.friendly_name {
        let v: Vec<u8> = n.encode_utf16().flat_map(u16::to_be_bytes).collect();
        attrs.push(der::seq(&[&der::oid(FRIENDLY_NAME), &der::set_of(&[&der::tlv(tag::BMP_STRING, &v)])]));
    }
    let attr_refs: Vec<&[u8]> = attrs.iter().map(Vec::as_slice).collect();
    let attr_set = der::set_of(&attr_refs);
    let cert_bag = |c: &Certificate, with_attrs: bool| {
        let value = der::explicit(0, &der::seq(&[&der::oid(X509_CERT), &der::explicit(0, &der::octets(&c.raw))]));
        if with_attrs { der::seq(&[&der::oid(CERT_BAG), &value, &attr_set]) } else { der::seq(&[&der::oid(CERT_BAG), &value]) }
    };
    let mut cert_bags = vec![cert_bag(&id.certificate, true)];
    cert_bags.extend(id.chain.iter().map(|c| cert_bag(c, false)));
    let certs_plain = der::seq(&cert_bags.iter().map(Vec::as_slice).collect::<Vec<_>>());
    let enc_certs = encrypt(&certs_plain)?;
    // EncryptedData: version 0, EncryptedContentInfo { data, algorithm, [0] IMPLICIT ct }.
    let enc_parts = Tlv::parse_all(&enc_certs)?.children()?;
    let eci = der::seq(&[&der::oid(DATA), enc_parts[0].raw, &der::tlv(tag::ctx_prim(0), enc_parts[1].value)]);
    let encrypted_data = der::seq(&[&der::int(0), &eci]);
    let ci_certs = der::seq(&[&der::oid(ENCRYPTED_DATA), &der::explicit(0, &encrypted_data)]);
    let key_bag = der::seq(&[&der::oid(SHROUDED_KEY_BAG), &der::explicit(0, &encrypt(id.key.pkcs8())?), &attr_set]);
    let ci_key = der::seq(&[&der::oid(DATA), &der::explicit(0, &der::octets(&der::seq(&[&key_bag])))]);
    let auth_safe = der::seq(&[&ci_certs, &ci_key]);
    let salt = random(16)?;
    let mac_key = pkcs12_kdf(DigestAlg::Sha256, &bmp(password), &salt, 3, ITER, 32);
    let mac = hmac(DigestAlg::Sha256, &mac_key, &auth_safe)?;
    let mac_data = der::seq(&[&der::seq(&[&DigestAlg::Sha256.algorithm(), &der::octets(&mac)]), &der::octets(&salt), &der::int(ITER as u64)]);
    Ok(der::seq(&[&der::int(3), &der::seq(&[&der::oid(DATA), &der::explicit(0, &der::octets(&auth_safe))]), &mac_data]))
}
