//! File ▸ Export ▸ AAF / OMF and their import, end to end with real media written by our encoders.

use std::sync::Arc;

use filmcraft_project::{ItemId, ItemKind, MediaRef, Param, ParamValue, TrackKind};
use filmcraft_time::FrameRate;
use serde_json::json;

use crate::Session;
use crate::media_test_util::{make_movie, session_with, tmp_dir};

/// Two 2-second ProRes + PCM movies cut back to back on V1/A1 (24 fps).
fn setup(name: &str) -> (Session, Vec<ItemId>, ItemId, std::path::PathBuf) {
    let dir = tmp_dir(name);
    let a = dir.join("a.mov");
    let b = dir.join("b.mov");
    make_movie(&a, filmcraft_media::DemoScene::Aurora, 64, 36, 48);
    make_movie(&b, filmcraft_media::DemoScene::Plasma, 64, 36, 48);
    let (mut s, items, seq) = session_with(&[&a, &b]);
    // trim both clips so handles exist: A plays media 12..36, B 6..30
    let rate = FrameRate::FPS_24;
    let mut p = (*s.project).clone();
    let q = p.sequence_mut(seq).unwrap();
    for t in q.all_tracks_mut() {
        for (i, c) in t.items.iter_mut().enumerate() {
            c.start = rate.tick_of(i as i64 * 24);
            c.source_in = rate.tick_of(if i == 0 { 12 } else { 6 });
            c.duration = rate.tick_of(24);
        }
    }
    s.project = Arc::new(p);
    (s, items, seq, dir)
}

fn audio_of(s: &Session, item: ItemId, start: i64, n: usize) -> Vec<Vec<f32>> {
    let src = s.media.full_res_source(&s.project, item, &*s.services).expect("online");
    src.audio(start, n, 48_000).unwrap().channels
}

fn imported_seq(r: &serde_json::Value) -> ItemId {
    let docs = r["documents"].as_array().cloned().unwrap_or_default();
    let seq = r["sequences"][0].as_u64().or_else(|| docs.first().and_then(|d| d["sequences"][0].as_u64())).unwrap_or_else(|| panic!("no sequence in {r}"));
    ItemId(seq)
}

fn path_of(s: &Session, item: ItemId) -> String {
    match &s.project.item(item).unwrap().kind {
        ItemKind::Media(m) => match &m.media {
            MediaRef::File { path } => path.clone(),
            _ => String::new(),
        },
        _ => String::new(),
    }
}

#[test]
fn aaf_embedded_trimmed_audio_round_trips_sample_exact() {
    let (mut s, items, seq, dir) = setup("aaf-embed");
    let path = dir.join("cut.aaf").to_string_lossy().into_owned();
    let r = s.execute("file.exportAaf", json!({"path": path, "audio": "embedded", "trimAudio": true, "handles": 6, "sequence": seq.0})).unwrap();
    assert!(r["mediaFiles"].as_array().unwrap().is_empty(), "{r}");
    let r = s.execute("file.import", json!({"paths": [path]})).unwrap();
    let n = imported_seq(&r);
    let q = s.project.sequence(n).unwrap().clone();
    let orig = s.project.sequence(seq).unwrap().clone();
    for kind in [TrackKind::Video, TrackKind::Audio] {
        let a: Vec<_> = q.tracks(kind)[0].items.iter().map(|c| (c.start, c.duration)).collect();
        let b: Vec<_> = orig.tracks(kind)[0].items.iter().map(|c| (c.start, c.duration)).collect();
        assert_eq!(a, b, "{kind:?}");
    }
    // video links to the original movies, audio to WAV files extracted next to the AAF
    assert_eq!(path_of(&s, q.video_tracks[0].items[0].item), path_of(&s, items[0]));
    for (c, oc) in q.audio_tracks[0].items.iter().zip(&orig.audio_tracks[0].items) {
        let p = path_of(&s, c.item);
        assert!(p.ends_with(".wav") && std::path::Path::new(&p).exists(), "{p}");
        assert!(!s.project.item(c.item).unwrap().as_media().unwrap().offline);
        // trimmed: the essence starts 6 frames (handles) before the clip
        assert_eq!(c.source_in, FrameRate::FPS_24.tick_of(6));
        let got = audio_of(&s, c.item, c.source_in.to_units_floor(48_000), 4800);
        let want = audio_of(&s, oc.item, oc.source_in.to_units_floor(48_000), 4800);
        for ch in 0..2 {
            for i in 0..4800 {
                assert!((got[ch][i] - want[ch][i]).abs() <= 1.0 / 32_768.0 + 1e-6, "ch {ch} sample {i}: {} vs {}", got[ch][i], want[ch][i]);
            }
        }
    }
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn aaf_separate_aiff_breakout_and_linked() {
    let (mut s, items, seq, dir) = setup("aaf-separate");
    let path = dir.join("sep.aaf").to_string_lossy().into_owned();
    let r = s
        .execute(
            "file.exportAaf",
            json!({"path": path, "audio": "separate", "audioFormat": "aiff", "bitDepth": 24, "breakoutToMono": true, "trimAudio": true, "handles": 0}),
        )
        .unwrap();
    let files: Vec<String> = r["mediaFiles"].as_array().unwrap().iter().map(|v| v.as_str().unwrap().to_string()).collect();
    assert_eq!(files.len(), 4, "two media × two channels: {r}");
    for f in &files {
        let b = std::fs::read(f).unwrap();
        let (pcm, ch, sr, bits) = filmcraft_interchange::wav::parse_aiff(&b).unwrap();
        assert_eq!((ch, sr, bits), (1, 48_000, 24));
        assert_eq!(pcm.len(), 24 * 2000 * 3, "one second of mono 24-bit audio (no handles)");
    }
    let r = s.execute("file.importAaf", json!({"path": path})).unwrap();
    let n = imported_seq(&r);
    let q = s.project.sequence(n).unwrap();
    let mono: Vec<_> = q.audio_tracks.iter().filter(|t| !t.items.is_empty()).collect();
    assert_eq!(mono.len(), 2);
    assert!(mono.iter().all(|t| t.channels == filmcraft_project::AudioChannels::Mono));

    // Avid-style consolidated OP-Atom MXF audio: our MXF reader opens every file
    let path = dir.join("mxf.aaf").to_string_lossy().into_owned();
    let r = s.execute("file.exportAaf", json!({"path": path, "audio": "separate", "audioFormat": "mxf", "breakoutToMono": true, "trimAudio": true})).unwrap();
    let files: Vec<String> = r["mediaFiles"].as_array().unwrap().iter().map(|v| v.as_str().unwrap().to_string()).collect();
    assert_eq!(files.len(), 4);
    for f in &files {
        let b = std::fs::read(f).unwrap();
        let m = filmcraft_mxf::open(&b).unwrap();
        assert_eq!(m.operational_pattern.name(), "OP-Atom");
        let t = m.track_of_kind(filmcraft_mxf::TrackKind::Sound).unwrap();
        assert_eq!(m.tracks[t].stored_sample_frames(), 48_000);
    }
    let r = s.execute("file.importAaf", json!({"path": path})).unwrap();
    let n = imported_seq(&r);
    let a = &s.project.sequence(n).unwrap().audio_tracks[0].items[0];
    assert!(path_of(&s, a.item).ends_with(".mxf"));
    assert!(!s.project.item(a.item).unwrap().as_media().unwrap().offline, "the MXF audio links");

    // linked: no media is written, the document points at the original movies
    let path = dir.join("linked.aaf").to_string_lossy().into_owned();
    let r = s.execute("file.exportAaf", json!({"path": path, "audio": "linked", "sequence": seq.0})).unwrap();
    assert!(r["mediaFiles"].as_array().unwrap().is_empty());
    let r = s.execute("file.import", json!({"paths": [path]})).unwrap();
    let n = imported_seq(&r);
    let q = s.project.sequence(n).unwrap();
    let a = &q.audio_tracks[0].items[0];
    assert_eq!(path_of(&s, a.item), path_of(&s, items[0]));
    assert_eq!(a.source_in, FrameRate::FPS_24.tick_of(12));
    assert!(!s.project.item(a.item).unwrap().as_media().unwrap().offline);
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn aaf_video_mixdown() {
    let (mut s, _items, seq, dir) = setup("aaf-mixdown");
    let path = dir.join("mix.aaf").to_string_lossy().into_owned();
    let r = s.execute("file.exportAaf", json!({"path": path, "mixdownVideo": true, "audio": "linked", "sequence": seq.0})).unwrap();
    let files = r["mediaFiles"].as_array().unwrap();
    assert_eq!(files.len(), 1);
    let mov = files[0].as_str().unwrap();
    assert!(mov.ends_with("Video Mixdown.mov") && std::path::Path::new(mov).exists());
    let r = s.execute("file.import", json!({"paths": [path]})).unwrap();
    let n = imported_seq(&r);
    let q = s.project.sequence(n).unwrap();
    assert_eq!(q.video_tracks.iter().map(|t| t.items.len()).sum::<usize>(), 1);
    let v = &q.video_tracks[0].items[0];
    assert_eq!(v.duration, FrameRate::FPS_24.tick_of(48));
    assert_eq!(path_of(&s, v.item), mov);
    let m = s.project.item(v.item).unwrap().as_media().unwrap();
    assert!(!m.offline);
    assert_eq!(m.info.video.as_ref().map(|v| (v.width, v.height)), Some((64, 36)));
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn omf_renders_clip_effects_into_embedded_audio() {
    let (mut s, _items, seq, dir) = setup("omf-render");
    // −6.0206 dB on the first audio clip: half amplitude
    let mut p = (*s.project).clone();
    let q = p.sequence_mut(seq).unwrap();
    q.audio_tracks[0].items[0].effect_mut("volume").unwrap().params.insert("level".into(), Param::new(ParamValue::Float(-6.020_599_913)));
    s.project = Arc::new(p);
    let orig = s.project.sequence(seq).unwrap().clone();
    let path = dir.join("mix.omf").to_string_lossy().into_owned();
    let r = s.execute("file.exportOmf", json!({"path": path, "renderAudioEffects": true, "handles": 0, "sequence": seq.0})).unwrap();
    assert!(r["bytes"].as_u64().unwrap() > 48_000 * 2 * 2, "audio is encapsulated: {r}");
    let r = s.execute("file.importAaf", json!({"path": path})).unwrap();
    let n = imported_seq(&r);
    let q = s.project.sequence(n).unwrap().clone();
    assert!(q.video_tracks.iter().all(|t| t.items.is_empty()));
    let a = &q.audio_tracks[0].items;
    assert_eq!(a.len(), 2);
    assert_eq!(
        a.iter().map(|c| (c.start, c.duration)).collect::<Vec<_>>(),
        orig.audio_tracks[0].items.iter().map(|c| (c.start, c.duration)).collect::<Vec<_>>()
    );
    // no gain left on the clips: it is in the samples
    assert!(a.iter().all(|c| c.effect("volume").and_then(|e| e.param("level")).is_none_or(|p| p.value.as_f64() == Some(0.0))));
    let oc = &orig.audio_tracks[0].items[0];
    let got = audio_of(&s, a[0].item, a[0].source_in.to_units_floor(48_000), 2400);
    let want = audio_of(&s, oc.item, oc.source_in.to_units_floor(48_000), 2400);
    let peak = want[0].iter().fold(0f32, |m, x| m.max(x.abs()));
    assert!(peak > 0.01, "the demo scene has audio");
    for i in 0..2400 {
        assert!((got[0][i] - want[0][i] * 0.5).abs() < 2e-3, "sample {i}: {} vs {}", got[0][i], want[0][i] * 0.5);
    }
    // the second clip is unchanged
    let oc2 = &orig.audio_tracks[0].items[1];
    let got = audio_of(&s, a[1].item, a[1].source_in.to_units_floor(48_000), 2400);
    let want = audio_of(&s, oc2.item, oc2.source_in.to_units_floor(48_000), 2400);
    for i in 0..2400 {
        assert!((got[0][i] - want[0][i]).abs() < 2e-3);
    }
    let _ = std::fs::remove_dir_all(dir);
}

#[test]
fn commands_are_registered_with_menus_and_validate_params() {
    for (id, menu) in [("file.exportAaf", &["File", "Export"][..]), ("file.exportOmf", &["File", "Export"][..]), ("file.importAaf", &[][..])] {
        let c = crate::commands::find(id).unwrap_or_else(|| panic!("{id}"));
        assert_eq!(c.menu, menu);
    }
    let (mut s, _, seq, dir) = setup("aaf-params");
    let path = dir.join("x.aaf").to_string_lossy().into_owned();
    assert!(s.execute("file.exportAaf", json!({"sequence": seq.0})).is_err(), "path is required");
    assert!(s.execute("file.exportAaf", json!({"path": path, "bitDepth": 20})).is_err());
    assert!(s.execute("file.exportOmf", json!({"path": path, "audio": "linked"})).is_err(), "OMF has no linked mode");
    assert!(s.execute("file.importAaf", json!({"path": dir.join("a.mov").to_string_lossy()})).is_err());
    let _ = std::fs::remove_dir_all(dir);
}
